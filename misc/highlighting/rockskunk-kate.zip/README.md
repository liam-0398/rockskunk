# rockskunk for Kate / KWrite / KDevelop

## Install

Copy `rockskunk.xml` into your user syntax directory:

```
~/.local/share/org.kde.syntax-highlighting/syntax/rockskunk.xml
```

(Create the directory if it doesn't exist.) Restart Kate/KWrite, open a
`.rsk` file, and it should be picked up automatically via the `*.rsk`
extension in the language definition -- no separate filetype step
needed, unlike the Vim version.

To confirm it loaded: bottom-right status bar (or Tools -> Highlighting)
should show "Rockskunk" as the detected mode. If it shows "Normal" or
something else, double check the file landed in the exact path above.

## Light and dark

This uses only semantic default styles (dsKeyword, dsControlFlow,
dsBuiltIn, dsFunction, dsString, etc) -- no hardcoded colors anywhere.
Kate resolves each of those against whichever color scheme is active
(Settings -> Configure Kate -> Editor Component -> Fonts & Colors), so
switching between a light and a dark scheme "just works" the same way
it does for every other language Kate ships with. Nothing to toggle or
configure separately for this.

## Notes on what this reflects

Checked against the actual compiler source, not just the language
README, so a few real quirks are baked in on purpose:

- `OR`/`AND` only work uppercase; lowercase `or`/`and` (as shown in some
  README examples) aren't actually recognized by the lexer.
- `NOR`/`XOR` work either all-uppercase or all-lowercase, not mixed case.
- `NOT` only works lowercase.
- `V`/`S`/`D`/`R` are only keywords when glued directly to a preceding
  `|` -- a variable named `v`, `R`, etc. elsewhere is just a variable.
- `'` is always a string quote to the lexer, never an optional statement
  terminator, despite some older documentation/examples suggesting
  otherwise. An unterminated string just stops highlighting at end of
  line instead of silently swallowing the rest of the file the way the
  real compiler currently does on the same mistake.
- Records, vector ops, and a handful of other things are highlighted as
  spec-only since the compiler doesn't implement them yet.

Same source-of-truth as the VS Code and Vim versions built earlier --
all three should behave consistently with each other.
